--****PLEASE ENTER YOUR DETAILS BELOW****
--T1a-rm-insert.sql
--Student ID:
--Student Name:
--Tutorial No:

/* Comments for your marker:




*/


/*
1(a) Load selected tables with your own additional test data
*/
--PLEASE PLACE REQUIRED SQL STATEMENT(S) FOR THIS PART HERE