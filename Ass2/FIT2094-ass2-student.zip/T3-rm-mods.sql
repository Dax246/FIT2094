--****PLEASE ENTER YOUR DETAILS BELOW****
--T3-rm-mods.sql
--Student ID:
--Student Name:
--Tutorial No:

/* Comments for your marker:




*/


/*
3(a) Changes to live database 1
*/
--PLEASE PLACE REQUIRED SQL STATEMENTS FOR THIS PART HERE











/*
3(b) Changes to live database 2
*/
--PLEASE PLACE REQUIRED SQL STATEMENTS FOR THIS PART HERE











/*
3(c) Changes to live database 3
*/
--PLEASE PLACE REQUIRED SQL STATEMENTS FOR THIS PART HERE











/*
3(d) Changes to live database 4
*/
--PLEASE PLACE REQUIRED SQL STATEMENTS FOR THIS PART HERE







