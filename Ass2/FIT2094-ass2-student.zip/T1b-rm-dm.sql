--****PLEASE ENTER YOUR DETAILS BELOW****
--T1b-rm-dm.sql
--Student ID:
--Student Name:
--Tutorial No:

/* Comments for your marker:




*/


/*
1b(i) Create sequences 
*/
--PLEASE PLACE REQUIRED SQL STATEMENT(S) FOR THIS PART HERE






/*
1b(ii) Take the necessary steps in the database to record data.
*/
--PLEASE PLACE REQUIRED SQL STATEMENT(S) FOR THIS PART HERE






/*
1b(iii) Take the necessary steps in the database to record changes. 
*/
--PLEASE PLACE REQUIRED SQL STATEMENT(S) FOR THIS PART HERE






/*
1b(iv) Take the necessary steps in the database to record changes. 
*/
--PLEASE PLACE REQUIRED SQL STATEMENT(S) FOR THIS PART HERE

